[Gateway]: gateway
[Bar]: bar
[Status Bar]: bar#status-bar
[User Configuration]: userconfig
[Status Center]: statuscenter
[Flight Mode]: flightmode
[Power Stretch]: powerstretch
[Timer]: timer
[Stopwatch]: stopwatch
[Settings]: settings
