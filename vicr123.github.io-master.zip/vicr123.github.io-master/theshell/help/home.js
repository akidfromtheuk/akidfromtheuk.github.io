function toggleContents(contents) {
    document.getElementById(contents).classList.toggle("closed");
}
