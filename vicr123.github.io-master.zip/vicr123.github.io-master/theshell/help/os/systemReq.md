---
title: System Requirements
tsVersion: OS 6.1 Apr.
project: theShell
projectIcon: /images/theshell.png
---

theShell OS requires the following to run properly:
- a 1 GHz processor (or faster)
- 8 GB of free space
- 2 GB of RAM to get past the installation. Once you've installed it you can drop it to 1 GB
